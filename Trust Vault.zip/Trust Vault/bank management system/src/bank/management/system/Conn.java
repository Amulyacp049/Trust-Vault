package bank.management.system;


import java.sql.*;

public class Conn {

    Connection c;
    Statement s;
    public Conn() {
       
        
        try { // db external entity error chance
            Class.forName("com.mysql.cj.jdbc.Driver");
            // driver name creation
            c = DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem", "root", "Amulyasql@123"); 
            s = c.createStatement();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}

