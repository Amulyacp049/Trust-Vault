package bank.management.system;

import javax.swing.*;
import java.awt.*; // for colors and fonts
import java.util.*; // for random number generation
import com.toedter.calendar.JDateChooser; // for calendar component
import java.awt.event.*; // for mouse click event handling

public class Signup2 extends JFrame implements ActionListener {

    JTextField nameTextField, aadhar, pan;
    JDateChooser dateChooser;
 
    JRadioButton yes, no, eyes, eno;
    JComboBox category, religion, education, occ, income;
    String formno;

    Signup2(String formno) {
        this.formno = formno;
        setLayout(null);
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 2");
        JLabel additionalDetail = new JLabel("Page 2: Additional Details");
        additionalDetail.setFont(new Font("Raleway", Font.BOLD, 24));
        additionalDetail.setBounds(240, 80, 400, 30);
        add(additionalDetail);

        JLabel name = new JLabel("Religion ");
        name.setFont(new Font("Raleway", Font.BOLD, 20));
        name.setBounds(100, 140, 100, 30);
        add(name);

        String valReligion[] = {"Select", "Hindu", "Muslim", "Sikh", "Christian", "other"};
        religion = new JComboBox(valReligion);
        religion.setBounds(350, 140, 400, 35);
        add(religion);

        JLabel fname = new JLabel("Category ");
        fname.setFont(new Font("Raleway", Font.BOLD, 20));
        fname.setBounds(100, 190, 160, 30);
        add(fname);

        String valCategory[] = {"Select", "General", "OBC", "SC", "ST", "others"};
        category = new JComboBox(valCategory);
        category.setBounds(350, 190, 400, 35);
        add(category);

        JLabel dob = new JLabel("Income");
        dob.setFont(new Font("Raleway", Font.BOLD, 20));
        dob.setBounds(100, 240, 200, 30);
        add(dob);

        String incomecategory[] = {"Select", "Null", "<1,50,000", "<2,50,000", "<5,00,000", "upto 10,00,000"};
        income = new JComboBox(incomecategory);
        income.setBounds(350, 240, 400, 30);
        add(income);

        JLabel gender = new JLabel("Educational");
        gender.setFont(new Font("Raleway", Font.BOLD, 20));
        gender.setBounds(100, 300, 200, 30);
        add(gender);

        JLabel email = new JLabel("Qualification ");
        email.setFont(new Font("Raleway", Font.BOLD, 20));
        email.setBounds(100, 325, 200, 30);
        add(email);

        String evalues[] = {"Select", "Non-graduate", "Graduate", "Post-graduation", "Doctrate", "others"};
        education = new JComboBox(evalues);
        education.setBounds(350, 315, 400, 30);
        add(education);

        JLabel mstatus = new JLabel("Occupation");
        mstatus.setFont(new Font("Raleway", Font.BOLD, 20));
        mstatus.setBounds(100, 390, 200, 30);
        add(mstatus);

        String occvalues[] = {"Select", "Salaried", "Self-employed", "Business", "Student", "Retired", "others"};
        occ = new JComboBox(occvalues);
        occ.setBounds(350, 390, 400, 30);
        add(occ);

        JLabel address = new JLabel("Pan No");
        address.setFont(new Font("Raleway", Font.BOLD, 20));
        address.setBounds(100, 440, 200, 30);
        add(address);

        pan = new JTextField();
        pan.setBounds(350, 440, 400, 35);
        pan.setFont(new Font("Raleway", Font.PLAIN, 20));
        add(pan);

        JLabel city = new JLabel("Aadhar No");
        city.setFont(new Font("Raleway", Font.BOLD, 20));
        city.setBounds(100, 490, 200, 30);
        add(city);

        aadhar = new JTextField();
        aadhar.setBounds(350, 490, 400, 35);
        aadhar.setFont(new Font("Raleway", Font.PLAIN, 20));
        add(aadhar);

        JLabel state = new JLabel("Senior citizen");
        state.setFont(new Font("Raleway", Font.BOLD, 20));
        state.setBounds(100, 540, 200, 30);
        add(state);

        yes = new JRadioButton("Yes");
        yes.setBounds(350, 540, 100, 30);
        yes.setBackground(Color.white);
        add(yes);

        no = new JRadioButton("No");
        no.setBounds(450, 540, 100, 30);
        no.setBackground(Color.white);
        add(no);

        ButtonGroup sc = new ButtonGroup(); // single button selection
        sc.add(yes);
        sc.add(no);

        JLabel pincode = new JLabel("Existing Account");
        pincode.setFont(new Font("Raleway", Font.BOLD, 20));
        pincode.setBounds(100, 590, 200, 30);
        add(pincode);

        eyes = new JRadioButton("Yes");
        eyes.setBounds(350, 590, 100, 30);
        eyes.setBackground(Color.white);
        add(eyes);

        eno = new JRadioButton("No");
        eno.setBounds(450, 590, 100, 30);
        eno.setBackground(Color.white);
        add(eno);

        ButtonGroup ea = new ButtonGroup(); // single button selection
        ea.add(eyes);
        ea.add(eno);

        JButton next = new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway", Font.BOLD, 20));
        next.setBounds(620, 660, 80, 30);
        next.addActionListener(this);
        add(next);

        getContentPane().setBackground(Color.white);
        setSize(850, 800); // Frame size
        setLocation(350, 10);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
       
        String sreligion = (String) religion.getSelectedItem();
        String scategory = (String) category.getSelectedItem();
        String sincome = (String) income.getSelectedItem();
        String seducation = (String) education.getSelectedItem();
        String socc = (String) occ.getSelectedItem();

        String seniorcitizen = null;
        if (yes.isSelected()) {
            seniorcitizen = "Yes";
        } else if (no.isSelected()) {
            seniorcitizen = "No";
        }

        String exisitingaccount = null;
        if (eyes.isSelected()) {
            exisitingaccount = "Yes";
        } else if (eno.isSelected()) {
            exisitingaccount = "No";
        }

        String span = pan.getText() ;
        String saadhar = aadhar.getText();

        try {
            Conn c = new Conn();
            String query = "insert into signup2 values('" + formno + "', '" + sreligion + "', '" + scategory + "', '"
                    + sincome + "', '" + seducation + "', '" + socc + "', '" + span + "', '" + saadhar + "', '"
                    + exisitingaccount + "', '" + seniorcitizen + "')";
            c.s.executeUpdate(query);

            // Transition to next form/page (Signup3)
           setVisible(false);
           new Signup3(formno).setVisible(true);
           
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Signup2(""));
    }
}
