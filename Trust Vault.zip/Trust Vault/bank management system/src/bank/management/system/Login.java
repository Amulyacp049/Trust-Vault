package bank.management.system;


import java.awt.*; //image library
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;

public class Login extends JFrame implements ActionListener { // frame of login page

    JButton login, signup, clear;
    JTextField cardTextField;
    JPasswordField pinTextField;

    Login() {
        
        //s = statement;

        setTitle("Automated Teller Machine");
        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH); // DEFAULT IMG
        ImageIcon i3 = new ImageIcon(i2);
        JLabel label = new JLabel(i3);
        label.setBounds(70, 10, 100, 100); // to left of label
        add(label); // into the frame

        JLabel text = new JLabel("WELCOME TO ATM");
        text.setBounds(200, 40, 400, 40);
        text.setFont(new Font("Osward", Font.BOLD, 38)); // text font on label
        add(text);

        JLabel cardno = new JLabel("CARD NO"); // card no in label
        cardno.setBounds(70, 150, 150, 40);
        cardno.setFont(new Font("Raleway", Font.BOLD, 28));
        add(cardno);
        cardTextField = new JTextField();
        cardTextField.setBounds(300, 155, 250, 40); // input for card no
        cardTextField.setFont(new Font("Raleway", Font.PLAIN, 24));
        add(cardTextField);

        JLabel pin = new JLabel("PIN"); // pin in label
        pin.setBounds(70, 220, 400, 40);
        pin.setFont(new Font("Raleway", Font.BOLD, 28));
        add(pin);
        pinTextField = new JPasswordField();
        pinTextField.setBounds(300, 230, 250, 40); // input for card no
        pinTextField.setFont(new Font("Raleway", Font.PLAIN, 24));
        add(pinTextField);

        login = new JButton("SIGN IN");
        login.setBounds(300, 310, 100, 30);
        login.setBackground(Color.black);
        login.setForeground(Color.white);
        login.addActionListener(this);
        add(login);

        clear = new JButton("Clear");
        clear.setBounds(450, 310, 100, 30);
        clear.setBackground(Color.black);
        clear.setForeground(Color.white);
        clear.addActionListener(this);
        add(clear);

        signup = new JButton("SIGN UP");
        signup.setBounds(300, 370, 250, 30);
        signup.setBackground(Color.black);
        signup.setForeground(Color.white);
        signup.addActionListener(this);
        add(signup);

        getContentPane().setBackground(Color.lightGray);
        setSize(800, 480); // dimension of frame
        setVisible(true);
        setLocation(350, 200); // chng def loc frm top left __|

        // getContentPanel();

    }

    // Button click event
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == clear) {
            cardTextField.setText(""); // clear text field
            pinTextField.setText("");
        } else if (ae.getSource() == login) {
            Conn conn = new Conn();  //from login page to direct transaction page
            String cardnumber = cardTextField.getText();
            String pinnumber = pinTextField.getText();
            String query = "select * from login where cardnumber = '"+cardnumber+"' and pin = '"+pinnumber+"'  ";
            
            try{
               ResultSet rs = conn.s.executeQuery(query);
               if(rs.next()){
                   setVisible(false);
                   new Transactions(pinnumber).setVisible(true);
               }else{
                   JOptionPane.showMessageDialog(null, "Incorrect card Number or pin");
               }
               
                
            }catch(Exception e){
                System.out.println(e);
            }
        } else if (ae.getSource() == signup) {
            setVisible(false);  // signup click
            new Signup1().setVisible(true);
        }

    }

    public static void main(String args[]) {
        new Login();
    }

}
