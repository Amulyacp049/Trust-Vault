package bank.management.system;

import javax.swing.*;
import java.awt.*; // for colors and fonts
import java.awt.event.*;
import java.sql.*;

public class MiniStatement extends JFrame {
    
    MiniStatement(String pinnumber) {
        setTitle("Mini Statement");
        setLayout(null);

        // Initialize components
        JLabel mini = new JLabel();
        mini.setBounds(20, 140, 400, 200); // Positioning the label on the frame
        add(mini);

        JLabel bank = new JLabel("Indian Bank");
        bank.setBounds(150, 20, 100, 80);
        add(bank);

        JLabel card = new JLabel();
        card.setBounds(20, 80, 300, 20);
        add(card);

        JLabel balance = new JLabel();
        balance.setBounds(20, 400, 300, 20);
        add(balance);

        // Fetch card number from login table
        try {
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from login where pin = '" + pinnumber + "'");
            while (rs.next()) {
                card.setText("Card Number: " + rs.getString("cardnumber").substring(0, 4) + "XXXXXXXX" + rs.getString("cardnumber").substring(12));
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        // Initialize balance and StringBuilder for transactions
        int bal = 0;
        StringBuilder miniStatement = new StringBuilder(); // StringBuilder for efficient string concatenation

        // Fetch transactions from bank table
        try {
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from bank where pin = '" + pinnumber + "' order by date");

            while (rs.next()) {
                String date = rs.getString("date");
                String type = rs.getString("type");
                String amount = rs.getString("amount");

                // Add transaction details to mini statement
                miniStatement.append(date).append("  ")
                        .append(type).append("  ")
                        .append(amount).append("<br>");

                // Update balance based on the transaction type
                if ("Deposit".equals(type)) {
                    bal += Integer.parseInt(amount);
                } else if ("Withdrawal".equals(type)) {
                    bal -= Integer.parseInt(amount);
                }
            }

            // Debugging: Check if transactions were fetched correctly
            System.out.println("Transaction History: " + miniStatement.toString());
            
        } catch (Exception e) {
            System.out.println(e);
        }

        // Set the transaction history and balance
        mini.setText("<html>" + miniStatement.toString() + "</html>"); // Wrap transactions in HTML format
        balance.setText("Your current account balance is Rs " + bal);

        // Finalize JFrame settings
        setSize(400, 600);
        setLocation(20, 20);
        getContentPane().setBackground(Color.WHITE);
        setVisible(true);
    }

    public static void main(String args[]) {
        new MiniStatement(" ").setVisible(true); // Use a sample PIN for testing
    }
}
